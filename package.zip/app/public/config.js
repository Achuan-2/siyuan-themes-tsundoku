export const config = {
    customJsonFilePath: '/temp/theme/custom.json',
};
